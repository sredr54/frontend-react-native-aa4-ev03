// src/components/TaskList.js
import React from 'react';
import { View, Text } from 'react-native';
import { styles } from '../styles/styles';

export default function TaskList() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Lista de tareas</Text>
      <Text style={styles.item}>Tarea 1</Text>
      <Text style={styles.item}>Tarea 2</Text>
      <Text style={styles.item}>Tarea 3</Text>
    </View>
  );
}
