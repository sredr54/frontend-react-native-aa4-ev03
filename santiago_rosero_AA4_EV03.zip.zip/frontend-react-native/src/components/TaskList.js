import React, { useState, useEffect } from "react";

// Componente encargado de la lógica del módulo
const TaskList = () => {
  // Estado para almacenar las tareas
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState("");

  // Efecto que se ejecuta al cargar el componente
  useEffect(() => {
    console.log("Módulo de tareas cargado correctamente");
  }, []);

  // Función para agregar una nueva tarea
  const addTask = () => {
    if (newTask.trim() === "") return;

    const task = {
      id: Date.now(),
      title: newTask,
      completed: false,
    };

    setTasks([...tasks, task]);
    setNewTask("");
  };

  // Función para eliminar una tarea
  const deleteTask = (id) => {
    const filteredTasks = tasks.filter(task => task.id !== id);
    setTasks(filteredTasks);
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Ingrese una tarea"
        value={newTask}
        onChange={(e) => setNewTask(e.target.value)}
      />

      <button onClick={addTask}>Agregar</button>

      <ul>
        {tasks.map(task => (
          <li key={task.id}>
            {task.title}
            <button onClick={() => deleteTask(task.id)}>Eliminar</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TaskList;
