import React from "react";
import TaskList from "../components/TaskList";

// Pantalla principal de la aplicación
const HomeScreen = () => {
  return <TaskList />;
};

export default HomeScreen;
