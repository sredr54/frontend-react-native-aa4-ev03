// src/styles/styles.js
// Archivo de estilos globales
// Evidencia GA7-220501096-AA4-EV03

import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    padding: 20,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  item: {
    padding: 10,
    backgroundColor: '#eaeaea',
    marginBottom: 5,
    borderRadius: 5,
  },
});
