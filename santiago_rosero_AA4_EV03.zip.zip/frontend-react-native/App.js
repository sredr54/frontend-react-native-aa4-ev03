// App.js
// Archivo principal de la aplicación
// Evidencia GA7-220501096-AA4-EV03

import React from 'react';
import { SafeAreaView } from 'react-native';
import HomeScreen from './src/screens/HomeScreen';

export default function App() {
  return (
    <SafeAreaView>
      <HomeScreen />
    </SafeAreaView>
  );
}
