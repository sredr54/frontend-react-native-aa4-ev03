# GA7-220501096-AA4-EV03  
## Componente Frontend – React Native (Móvil)

### Programa de formación
Análisis y Desarrollo de Software

### Evidencia
GA7-220501096-AA4-EV03 – Componente frontend del proyecto formativo y proyectos de clase

---

## 📱 Descripción del proyecto

Este proyecto corresponde al desarrollo de un **módulo frontend móvil** utilizando **React Native**, aplicando los conocimientos adquiridos en el componente formativo **“Desarrollo de frontend con React JS”**.

El módulo implementa la gestión básica de tareas, permitiendo al usuario:
- Agregar tareas
- Visualizar tareas
- Eliminar tareas

El desarrollo sigue buenas prácticas de codificación, uso de componentes funcionales, hooks y control de versiones.

---

## 🛠️ Tecnologías utilizadas

- React Native
- JavaScript (ES6+)
- Expo
- Node.js
- Git y GitHub

---

## 📂 Estructura del proyecto

